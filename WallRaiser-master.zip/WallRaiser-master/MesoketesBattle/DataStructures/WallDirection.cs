﻿namespace MesoketesBattle.DataStructures
{
    public enum WallDirection
    {
        Unknown = 0,
        N = 1,
        E = 2,
        S = 3,
        W = 4
    }
}
