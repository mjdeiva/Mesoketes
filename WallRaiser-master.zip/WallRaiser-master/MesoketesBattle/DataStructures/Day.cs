﻿using System.Collections.Generic;

namespace MesoketesBattle
{
    public class Day
    {
        public string Name { get; set; }
        public List<Attack> Attacks { get; set; }
    }
}
