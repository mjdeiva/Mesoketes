﻿namespace MesoketesBattle
{
    public enum Weapon
    {
        Unknown = 0,
        X = 1,
        Y = 2
    }
}
